package com.codingame.view;

import java.util.List;

public class PlayerData {
    int sun, score;
    public List<Integer> activated;
    public boolean isWaiting;
    public String message;
    public List<Integer> affected;
}
