package com.codingame.view;

public class ShadowData {
    int index;
    int size;

}
