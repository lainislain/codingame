package com.codingame.view;

import java.util.List;

public class GlobalViewData {

    public List<CellData> cells;
    public List<Integer> nutrients;
    public int totalRounds;

}
