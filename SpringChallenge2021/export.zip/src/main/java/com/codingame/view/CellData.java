package com.codingame.view;

public class CellData {
    int q, r, richness, index;

}
