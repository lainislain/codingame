package com.codingame.view;

public class TreeData {
    int index, size, owner, sunPoints;
    boolean isDormant;

}
