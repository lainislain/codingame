package com.codingame.view;

public class SeedData {
    int owner, sourceIndex, targetIndex;

}
