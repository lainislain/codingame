package com.codingame.view;

import java.util.List;

public class EventData {

    public List<AnimationData> animData;

}
