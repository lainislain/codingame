package com.codingame.game;

public enum FrameType {
    GATHERING,
    ACTIONS,
    SUN_MOVE,
    INIT
}
