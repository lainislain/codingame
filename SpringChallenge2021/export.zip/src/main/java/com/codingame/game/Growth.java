package com.codingame.game;

public class Growth {
    public int targetId;
    public Player player;
    public int cost;
}
