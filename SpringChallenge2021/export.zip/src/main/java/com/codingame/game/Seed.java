package com.codingame.game;

public class Seed {
    private int owner;
    private int sourceCell;
    private int targetCell;

    public int getOwner() {
        return owner;
    }

    public void setOwner(int owner) {
        this.owner = owner;
    }

    public int getSourceCell() {
        return sourceCell;
    }

    public void setSourceCell(int sourceCell) {
        this.sourceCell = sourceCell;
    }

    public int getTargetCell() {
        return targetCell;
    }

    public void setTargetCell(int targetCell) {
        this.targetCell = targetCell;
    }

}
