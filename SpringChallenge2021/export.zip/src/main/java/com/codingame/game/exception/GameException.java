package com.codingame.game.exception;

@SuppressWarnings("serial")
public class GameException extends Exception {

    public GameException(String string) {
        super(string);
    }

}
