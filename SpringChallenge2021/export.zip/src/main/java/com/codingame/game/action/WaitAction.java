package com.codingame.game.action;

public class WaitAction extends Action {

    @Override
    public boolean isWait() {
        return true;
    }
}
