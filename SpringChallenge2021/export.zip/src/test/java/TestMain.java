public class TestMain {
    public static void main(String[] args) {
        System.setProperty("league.level", "1");
        System.setProperty("allow.config.override", "true");

    }

}
